import service as service
import json
import requests
import urls as urls
from flask import Flask, request, jsonify
from models import db, Carts

app = Flask(__name__)


@app.route("/get_cart/<int:id>", methods=["GET"])
def get_cart(id):
    carts = Carts.query.filter_by(user_id=id)
    return (
        jsonify(
            {
                "cart": [
                    {
                        "id": cart.id,
                        "user_id": cart.user_id,
                        "product_id": cart.product_id,
                        "quantity": cart.quantity,
                    }
                    for cart in carts
                ]
            }
        ),
        200,
    )


def get_cart_by_id(id):
    carts = Carts.query.filter_by(user_id=id)
    return [
        {
            "id": cart.id,
            "user_id": cart.user_id,
            "product_id": cart.product_id,
            "quantity": cart.quantity,
        }
        for cart in carts
    ]


@app.route("/add_cart", methods=["POST"])
def add_to_cart():
    data = request.json
    product_id = data.get("product_id")
    user_id = data.get("user_id")
    quantity = data.get("quantity")

    if Carts.query.filter_by(product_id=product_id, user_id=user_id).first():
        return jsonify({"message": "Item already added to cart"}), 200
    product_id, user_id, quantity = (
        data["product_id"],
        data["user_id"],
        data["quantity"],
    )
    cart_item = Carts(product_id=product_id, user_id=user_id, quantity=quantity)
    service.add_to_cart_service(cart_item)

    return jsonify({"message": "Items added to cart successfully"}), 200


@app.route("/update_cart", methods=["PUT"])
def update_cart():
    cart_data = request.json["cart"]
    for data in cart_data:
        product_id = data.get("product_id")
        user_id = data.get("user_id")
        quantity = data.get("quantity")
        cart_item = Carts.query.filter_by(
            product_id=product_id, user_id=user_id
        ).first()
        if cart_item:
            cart_item.quantity = quantity
            service.update_cart()
        else:
            return jsonify({"error": "Cart item not found"}), 404
    return jsonify({"message": "Cart updated successfully"}), 200


@app.route("/cart/clear/<int:user_id>", methods=["DELETE"])
def clear_cart(user_id):
    carts = Carts.query.filter_by(user_id=user_id).all()
    if carts:
        for cart in carts:
            service.clear_cart(cart)
        return jsonify({"message": "Cart cleared successfully"}), 200
    else:
        return jsonify({"error": "Cart not found"}), 404


@app.route("/checkout", methods=["POST"])
def checkout():
    data = request.json
    user_id = data["user_id"]
    carts = get_cart_by_id(user_id)
    response = requests.post(
        urls.order_service_url + "/checkout", json={"content": carts}
    )
    response_content_str = response.content.decode("utf-8")
    res = json.loads(response_content_str)

    if res["Order_Status"] == "Successfully placed order":
        clear_cart(user_id)
        return jsonify({"response": "Order placed successfully"})
    else:
        return jsonify({"response": "Error in placing order, please try again later."})


@app.route("/increase_quantity/<int:user_id>/<int:product_id>", methods=["POST"])
def increase_quantity(user_id, product_id):
    cart_item = Carts.query.filter_by(user_id=user_id, product_id=product_id).first()
    if cart_item:
        cart_item.quantity += 1
        service.increase_quantity()
        return jsonify({"message": "Quantity increased successfully"}), 200
    else:
        return jsonify({"error": "Cart item not found"}), 404


@app.route("/decrease_quantity/<int:user_id>/<int:product_id>", methods=["POST"])
def decrease_quantity(user_id, product_id):
    cart_item = Carts.query.filter_by(user_id=user_id, product_id=product_id).first()
    if cart_item:
        if cart_item.quantity == 1:
            service.decrease_quantity(cart_item)
            return jsonify({"message": "Product removed successfully"}), 200
        if cart_item.quantity > 1:
            cart_item.quantity -= 1
            service.decrease_quantity()
            return jsonify({"message": "Quantity decreased successfully"}), 200
        else:
            return jsonify({"error": "Quantity cannot be less than 1"}), 400
    else:
        return jsonify({"error": "Cart item not found"}), 404
