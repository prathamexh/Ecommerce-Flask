from models import db


def add_to_cart_service(cart_item):
    try:
        print(cart_item)
        db.session.add(cart_item)
        db.session.commit()
        print("Added Successfully")
    except:
        print("Error adding")


def increase_quantity():
    db.session.commit()


def decrease_quantity(*args):
    if args:
        db.session.delete(args[0])
        db.session.commit()
    else:
        db.session.commit()


def update_cart():
    db.session.commit()
    pass


def clear_cart(cart_item):
    db.session.delete(cart_item)
    db.session.commit()
