import pytest
import json
from flask import Flask
from controller import app
import requests

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_checkout_success(mocker, client):
    # Mock get_cart_by_id function
    mock_get_cart_by_id = mocker.patch('controller.get_cart_by_id', return_value=[{"id": 1, "user_id": 1, "product_id": 1, "quantity": 1}])
    
    # Mock the requests.post call
    mock_response = mocker.Mock()
    mock_response.content.decode.return_value = json.dumps({"Order_Status": "Successfully placed order"})
    mock_requests_post = mocker.patch('requests.post', return_value=mock_response)
    
    # Mock the clear_cart function
    mock_clear_cart = mocker.patch('controller.clear_cart')
    
    # Make a POST request to the /checkout endpoint
    response = client.post('/checkout', json={"user_id": 1})
    
    # Assert the response
    assert response.status_code == 200
    assert response.json == {"response": "Order placed successfully"}
    
    # Ensure the mocks were called as expected
    mock_get_cart_by_id.assert_called_once_with(1)
    mock_requests_post.assert_called_once_with('http://127.0.0.1:7000/checkout', json={"content": [{"id": 1, "user_id": 1, "product_id": 1, "quantity": 1}]})
    mock_clear_cart.assert_called_once_with(1)

def test_checkout_failure(mocker, client):
    # Mock get_cart_by_id function
    mock_get_cart_by_id = mocker.patch('controller.get_cart_by_id', return_value=[{"id": 1, "user_id": 1, "product_id": 1, "quantity": 1}])
    
    # Mock the requests.post call
    mock_response = mocker.Mock()
    mock_response.content.decode.return_value = json.dumps({"Order_Status": "Error in placing order"})
    mock_requests_post = mocker.patch('requests.post', return_value=mock_response)
    
    # Make a POST request to the /checkout endpoint
    response = client.post('/checkout', json={"user_id": 1})
    
    # Assert the response
    assert response.status_code == 200
    assert response.json == {"response": "Error in placing order, please try again later."}
    
    # Ensure the mocks were called as expected
    mock_get_cart_by_id.assert_called_once_with(1)
    mock_requests_post.assert_called_once_with('http://127.0.0.1:7000/checkout', json={"content": [{"id": 1, "user_id": 1, "product_id": 1, "quantity": 1}]})

