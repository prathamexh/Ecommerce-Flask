from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Carts(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer)
    user_id = db.Column(db.Integer)
    quantity = db.Column(db.Integer)
