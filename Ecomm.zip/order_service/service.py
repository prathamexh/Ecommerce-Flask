from models import db


def add_order(order):
    db.session.add(order)
    db.session.commit()
