catelogue_service_url = "http://127.0.0.1:600"
payment_service_url = "http://127.0.0.1:8000"
