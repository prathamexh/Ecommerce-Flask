from flask import Flask, request, jsonify
import requests
from models import db, Orders
import service as service
import urls as url
import datetime
import json

app = Flask(__name__)


@app.route("/get_order/<int:id>", methods=["GET"])
def get_cart(id):
    carts = Orders.query.filter_by(user_id=id)
    return (
        jsonify(
            [
                {
                    "user_id": cart.user_id,
                    "product_id": cart.product_id,
                    "quantity": cart.quantity,
                }
                for cart in carts
            ]
        ),
        200,
    )


def get_new_id():
    max_order_id = db.session.query(db.func.max(Orders.order_id)).scalar()
    if max_order_id is None:
        return 1  # If there are no existing orders, start from 1
    else:
        return max_order_id + 1


@app.route("/checkout", methods=["POST"])
def checkout():
    data = request.json
    data = data["content"]
    amount = 0
    club_id = get_new_id()
    date = datetime.datetime.now()
    for d in data:
        response = requests.get(
            url.catelogue_service_url + "/product_by_id/" + str(d["product_id"])
        )
        response_content_str = response.content.decode("utf-8")
        temp = json.loads(response_content_str)  # Parse the string as JSON
        amount += d["quantity"] * temp["price"]
        order = Orders(
            club_id=club_id,
            user_id=d["user_id"],
            product_id=d["product_id"],
            quantity=d["quantity"],
            date=date,
            amount=amount,
            status="pending",
        )
        service.add_order(order)

    if connect_payments(club_id, data[0]["user_id"], amount):
        return jsonify({"Order_Status": "Successfully placed order"})
    else:
        return jsonify({"Order_Status": "Payment pending"})


def connect_payments(club_id, user_id, amount):
    data = {"user_id": user_id, "amount": amount}
    response = requests.post(
        url.payment_service_url + "/process_transaction/", json=data
    )
    response_content_str = response.content.decode("utf-8")
    res = json.loads(response_content_str)
    if res["status"] == "completed":
        order = Orders.query.filter_by(club_id=club_id)
        for o in order:
            o.status = "completed"
            db.session.commit()
        return True
    return False


@app.route("/get_orders/<int:user_id>", methods=["GET"])
def get_order(user_id):
    order = Orders.query.filter_by(user_id=user_id)
    res = [
        {
            "user_id": o.user_id,
            "product_id": o.product_id,
            "quantity": o.quantity,
            "club_id": o.club_id,
            "date": o.date,
            "amount": o.amount,
            "status": o.status,
        }
        for o in order
    ]
    return jsonify({"orders": res})


@app.route("/cancel_order", methods=["PUT"])
def cancel_order():
    data = request.json
    user_id = data["user_id"]
    club_id = data["club_id"]
    amount = data["amount"]
    try:
        response = requests.put(
            url.payment_service_url + "/cancel_order/",
            json={"user_id": user_id, "amount": amount},
        )
        if response.status_code == 200:
            order = Orders.query.filter_by(club_id=club_id)
            for o in order:
                o.status = "cancelled"
                db.session.commit()
            return jsonify({"message": "Order cancelled successfully"})
        else:
            return jsonify({"message": "could not cancel order."})

    except:
        return jsonify({"message": "could not cancel order."})


@app.route("/get_all_valid", methods=["GET"])
def get_all():
    order = Orders.query.all()
    res = [
        {
            "order_id": o.order_id,
            "user_id": o.user_id,
            "product_id": o.product_id,
            "quantity": o.quantity,
            "club_id": o.club_id,
            "date": o.date,
            "amount": o.amount,
            "status": o.status,
        }
        for o in order
    ]
    return jsonify({"orders": res})


@app.route("/change_status/<id>", methods=["POST"])
def change_status(id):
    order = Orders.query.filter_by(club_id=id)
    for o in order:
        if o.status == "completed":
            o.status = "in-transit"
            db.session.commit()
        elif o.status == "in-transit":
            o.status = "delivered"
            db.session.commit()
        else:
            return jsonify({"response": "cant change status without payment"}), 400
    return jsonify({"response": "successfully changed the status"}), 200
