from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Orders(db.Model):
    order_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    club_id = db.Column(db.Integer)
    product_id = db.Column(db.Integer)
    user_id = db.Column(db.Integer)
    quantity = db.Column(db.Integer)
    date = db.Column(db.Date)
    amount = db.Column(db.Float)
    status = db.Column(db.String(50))
