"""
URL configuration for myproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path

# from ./myapp/views import create_user
from myapp import views

urlpatterns = [
    path("process_transaction/", views.process_transaction, name="process_transaction"),
    path("create_user/", views.create_user, name="create_user"),
    path("update_balance/", views.add_balance, name="add_balance"),
    path("get_balance/<int:user_id>/", views.get_balance, name="get_balance"),
    path("cancel_order/", views.cancel_order, name="cancel_order"),
]
