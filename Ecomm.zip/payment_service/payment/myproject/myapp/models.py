from django.db import models


class UserBalance(models.Model):
    user_id = models.IntegerField(primary_key=True)
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    class Meta:
        app_label = "myapp"
