from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import UserBalance
from .serializers import UserBalanceSerializer


@api_view(["POST"])
def create_user(request):
    # Assign default balance of 100000 on user creation
    serializer = UserBalanceSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save(balance=100000)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(["PUT"])
def add_balance(request):
    user_id = request.data.get("user_id")
    add_amount = request.data.get("amount")
    try:
        user_balance = UserBalance.objects.get(user_id=user_id)
    except UserBalance.DoesNotExist:
        return Response({"error": "User balance not found"}, status=404)

    user_balance.balance += add_amount
    user_balance.save()
    return Response(
        {"status": "completed", "new_balance": user_balance.balance}, status=200
    )


@api_view(["PUT"])
def cancel_order(request):
    user_id = request.data.get("user_id")
    add_amount = request.data.get("amount")
    try:
        user_balance = UserBalance.objects.get(user_id=user_id)
    except UserBalance.DoesNotExist:
        return Response({"error": "User balance not found"}, status=404)

    user_balance.balance += add_amount
    user_balance.save()
    return Response(
        {"status": "completed", "new_balance": user_balance.balance}, status=200
    )


@api_view(["GET"])
def get_balance(request, user_id):
    try:
        user_balance = UserBalance.objects.get(user_id=user_id)
    except UserBalance.DoesNotExist:
        return Response({"error": "User balance not found"}, status=404)

    user_balance.save()
    return Response({"balance": user_balance.balance})


@api_view(["POST"])
def process_transaction(request):
    user_id = request.data.get("user_id")
    amount = request.data.get("amount")

    try:
        user_balance = UserBalance.objects.get(user_id=user_id)
    except UserBalance.DoesNotExist:
        return Response({"error": "User balance not found"}, status=404)

    if user_balance.balance < amount:
        return Response(
            {"error": "Transaction failed. Insufficient balance."}, status=400
        )

    user_balance.balance -= amount
    user_balance.save()

    return Response({"status": "completed", "new_balance": user_balance.balance})
