from django.test import TestCase

# Create your tests here.
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from .models import UserBalance


class UserBalanceTests(APITestCase):

    def setUp(self):
        self.user_id = 1
        self.create_user_url = reverse("create_user")
        self.process_transaction_url = reverse("process_transaction")
        self.add_balance_url = reverse("add_balance")
        self.get_balance_url = reverse("get_balance", args=[self.user_id])
        self.cancel_order_url = reverse("cancel_order")
        print("look here boy", self.add_balance_url)

    def test_create_user(self):
        data = {"user_id": self.user_id}
        response = self.client.post(self.create_user_url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(str(response.data["balance"]), "100000.00")
        self.assertTrue(UserBalance.objects.filter(user_id=self.user_id).exists())

    def test_add_balance(self):
        UserBalance.objects.create(user_id=self.user_id, balance=100)
        data = {"user_id": self.user_id, "amount": 50}
        response = self.client.put(self.add_balance_url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(str(response.data["new_balance"]), "150.00")

    def test_cancel_order(self):
        UserBalance.objects.create(user_id=self.user_id, balance=100)
        data = {"user_id": self.user_id, "amount": 50}
        response = self.client.put(self.cancel_order_url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(str(response.data["new_balance"]), "150.00")

    def test_get_balance(self):
        UserBalance.objects.create(user_id=self.user_id, balance=100)
        response = self.client.get(self.get_balance_url, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(str(response.data["balance"]), "100.00")

    def test_process_transaction_success(self):
        UserBalance.objects.create(user_id=self.user_id, balance=100)
        data = {"user_id": self.user_id, "amount": 50}
        response = self.client.post(self.process_transaction_url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(str(response.data["new_balance"]), "50.00")

    def test_process_transaction_insufficient_balance(self):
        UserBalance.objects.create(user_id=self.user_id, balance=30)
        data = {"user_id": self.user_id, "amount": 50}
        response = self.client.post(self.process_transaction_url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(
            response.data["error"], "Transaction failed. Insufficient balance."
        )

    def test_add_balance_user_not_found(self):
        data = {"user_id": self.user_id, "amount": 50}
        response = self.client.put(self.add_balance_url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertEqual(response.data["error"], "User balance not found")

    def test_cancel_order_user_not_found(self):
        data = {"user_id": self.user_id, "amount": 50}
        response = self.client.put(self.cancel_order_url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertEqual(response.data["error"], "User balance not found")

    def test_get_balance_user_not_found(self):
        response = self.client.get(self.get_balance_url, format="json")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertEqual(response.data["error"], "User balance not found")

    def test_process_transaction_user_not_found(self):
        data = {"user_id": self.user_id, "amount": 50}
        response = self.client.post(self.process_transaction_url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertEqual(response.data["error"], "User balance not found")
