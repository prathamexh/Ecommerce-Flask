from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


# Define Catalogue Model
class Catalogue(db.Model):
    Product_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    Product_name = db.Column(db.String(255), nullable=False)
    Description = db.Column(db.String(255), nullable=False)
    Category = db.Column(db.String(255), nullable=False)
    Price = db.Column(db.Integer, nullable=False)
    Discount = db.Column(db.Integer, nullable=False)
    in_Stock = db.Column(db.Boolean, nullable=False)
    Inventory_id = db.Column(db.Integer)


# Define Inventory Model
class Inventory(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    address = db.Column(db.String(255), nullable=False)
    provider_name = db.Column(db.String(255), nullable=False)
    inventory_name = db.Column(db.String(255), nullable=False)
    # quantity = db.Column(db.Integer)


# Define Review Model
class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    product_id = db.Column(db.Integer)
    user_id = db.Column(db.Integer)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.String(255), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
