import pytest
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from app import app, db, Catalogue, Review, Inventory


# Configure the application for testing
@pytest.fixture(scope="module")
def test_client():
    app.config["TESTING"] = True
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///catelogue1.db"
    with app.app_context():
        db.create_all()
        yield app.test_client()
        db.drop_all()


@pytest.fixture(scope="module")
def init_database():
    with app.app_context():
        # Add some test data to the database
        product = Catalogue(
            Product_name="Test Product",
            Description="Test Description",
            Category="Test Category",
            Price=100,
            Discount=10,
            in_Stock=True,
            Inventory_id=None,
        )
        review = Review(
            product_id=1,
            user_id=1,
            title="Test Review",
            description="This is a test review",
            rating=5,
        )
        inventory = Inventory(
            address="123 Test St",
            provider_name="Test Provider",
            inventory_name="Test Inventory",
        )
        db.session.add(product)
        db.session.add(review)
        db.session.add(inventory)
        db.session.commit()
        yield db
        db.session.remove()


def test_get_all_products(test_client, init_database):
    response = test_client.get("/")
    assert response.status_code == 200
    data = response.get_json()
    assert len(data) == 1
    assert data[0]["product_name"] == "Test Product"


def test_get_product_by_id(test_client, init_database):
    response = test_client.get("/product_by_id/1")
    assert response.status_code == 200
    data = response.get_json()
    assert data["product_name"] == "Test Product"
    assert data["price"] == 100


def test_add_product(test_client, init_database):
    new_product = {
        "product_name": "New Product",
        "description": "New Description",
        "category": "New Category",
        "price": 200,
        "discount": 20,
        "in_stock": True,
        "inventory_id": None,
    }
    response = test_client.post("/addProduct", json=new_product)
    assert response.status_code == 201
    data = response.get_json()
    assert data["message"] == "Product added successfully"


def test_update_product(test_client, init_database):
    updated_product = {
        "product_name": "Updated Product",
        "description": "Updated Description",
        "category": "Updated Category",
        "price": 300,
        "discount": 30,
        "in_stock": False,
        "inventory_id": None,
    }
    response = test_client.put("/update_product/1", json=updated_product)
    assert response.status_code == 200
    data = response.get_json()
    assert data["message"] == "Product updated successfully"


def test_delete_product(test_client, init_database):
    response = test_client.delete("/delete_product/1")
    assert response.status_code == 200
    data = response.get_json()
    assert data["message"] == "Product deleted successfully"


def test_get_reviews(test_client, init_database):
    response = test_client.get("/get_reviews/1")
    assert response.status_code == 200
    data = response.get_json()
    assert len(data) == 1
    assert data[0]["title"] == "Test Review"


def test_add_review(test_client, init_database):
    new_review = {
        "product_id": 1,
        "user_id": 2,
        "title": "Another Review",
        "description": "This is another test review",
        "rating": 4,
    }
    response = test_client.post("/add_review", json=new_review)
    assert response.status_code == 201
    data = response.get_json()
    assert data["message"] == "Review added successfully"


def test_get_inventory(test_client, init_database):
    response = test_client.get("/get_inventory/1")
    assert response.status_code == 200
    data = response.get_json()
    assert data["address"] == "123 Test St"


def test_add_inventory(test_client, init_database):
    new_inventory = {
        "address": "456 Another St",
        "provider_name": "Another Provider",
        "inventory_name": "Another Inventory",
    }
    response = test_client.post("/add_inventory", json=new_inventory)
    assert response.status_code == 201
    data = response.get_json()
    assert data["message"] == "Inventory added successfully"


def test_update_inventory(test_client, init_database):
    updated_inventory = {
        "address": "789 Updated St",
        "provider_name": "Updated Provider",
        "inventory_name": "Updated Inventory",
    }
    response = test_client.put("/update_inventory/1", json=updated_inventory)
    assert response.status_code == 200
    data = response.get_json()
    assert data["message"] == "Inventory updated successfully"


def test_delete_inventory(test_client, init_database):
    response = test_client.delete("/delete_inventory/1")
    assert response.status_code == 200
    data = response.get_json()
    assert data["message"] == "Inventory deleted successfully"
