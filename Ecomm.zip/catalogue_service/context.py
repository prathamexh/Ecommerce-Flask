from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


# Define Catalogue Model
class Catalogue(db.Model):
    Product_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    Product_name = db.Column(db.String(255), nullable=False)
    Description = db.Column(db.String(255), nullable=False)
    Category = db.Column(db.String(255), nullable=False)
    Price = db.Column(db.Integer, nullable=False)
    Discount = db.Column(db.Integer, nullable=False)
    in_Stock = db.Column(db.Boolean, nullable=False)
    Inventory_id = db.Column(db.Integer)


# Define Inventory Model
class Inventory(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    address = db.Column(db.String(255), nullable=False)
    provider_name = db.Column(db.String(255), nullable=False)
    inventory_name = db.Column(db.String(255), nullable=False)
    # quantity = db.Column(db.Integer)


# Define Review Model
class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    product_id = db.Column(db.Integer)
    user_id = db.Column(db.Integer)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.String(255), nullable=False)
    rating = db.Column(db.Integer, nullable=False)


from flask import Flask
from models import db
from controller import app
from flask_cors import CORS

CORS(app, origins="*")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///catelogue.db"
db.init_app(app)

# Create the database tables
with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(port=600, debug=True)

from flask import Flask, request, jsonify
from models import db, Catalogue, Review, Inventory
import json

app = Flask(__name__)


@app.route("/", methods=["GET"])
def get_all():
    data = Catalogue.query.all()
    products = []
    for d in data:
        product = {
            "product_id": d.Product_id,
            "product_name": d.Product_name,
            "description": d.Description,
            "category": d.Category,
            "price": d.Price,
            "discount": d.Discount,
            "in_stock": d.in_Stock,
            "inventory_id": d.Inventory_id,
        }
        products.append(product)
    return jsonify(products)


@app.route("/product_by_id/<id>", methods=["GET"])
def get_product_by_id(id):
    data = Catalogue.query.filter_by(Product_id=id).first()
    print(data)
    print(data.Price)
    effective_price = data.Price
    return jsonify({"price": effective_price, "product_name": data.Product_name})


@app.route("/addProduct", methods=["POST"])
def add_product():
    data = request.json
    print(data)
    print("Heloo check here")
    product_name = data.get("product_name")
    description = data.get("description")
    category = data.get("category")
    price = data.get("price")
    discount = data.get("discount")
    in_stock = data.get("in_stock")
    if in_stock == True:
        in_stock = 1
    else:
        in_stock = 0
    inventory_id = data.get("inventory_id")

    try:
        new_product = Catalogue(
            Product_name=product_name,
            Description=description,
            Category=category,
            Price=int(price),
            Discount=int(discount),
            in_Stock=in_stock,
            Inventory_id=inventory_id,
        )
        db.session.add(new_product)
        db.session.commit()
        return jsonify({"message": "Product added successfully"}), 201
    except:
        return jsonify({"message": "Error adding this item"}), 400


@app.route("/update_product/<int:product_id>", methods=["PUT"])
def update_product(product_id):

    product = Catalogue.query.get(product_id)
    if not product:
        return jsonify({"message": "Product not found"}), 404

    data = request.json
    print(data)
    print("Heloo check here")
    product.Product_name = data.get("product_name", product.Product_name)
    product.Description = data.get("description", product.Description)
    product.Category = data.get("category", product.Category)
    product.Price = data.get("price", product.Price)
    product.Discount = data.get("discount", product.Discount)
    product.in_Stock = data.get("in_stock", product.in_Stock)
    product.Inventory_id = data.get("inventory_id", product.Inventory_id)
    db.session.commit()
    return jsonify({"message": "Product updated successfully"}), 200


@app.route("/delete_product/<int:product_id>", methods=["DELETE"])
def delete_product(product_id):
    product = Catalogue.query.get(product_id)
    if product:
        db.session.delete(product)
        db.session.commit()
        return jsonify({"message": "Product deleted successfully"}), 200
    else:
        return jsonify({"message": "Product not found"}), 404


""" 
Reviews
"""


@app.route("/get_reviews/<int:product_id>", methods=["GET"])
def get_reviews(product_id):
    reviews = Review.query.filter_by(product_id=product_id).all()
    if not reviews:
        return jsonify({"message": "No reviews found for this product"}), 404

    review_list = []
    for review in reviews:
        review_data = {
            "id": review.id,
            "product_id": review.product_id,
            "user_id": review.user_id,
            "title": review.title,
            "description": review.description,
            "rating": review.rating,
        }
        review_list.append(review_data)

    return jsonify(review_list)


@app.route("/add_review", methods=["POST"])
def add_review():
    data = request.json
    product_id = data.get("product_id")
    user_id = data.get("user_id")
    title = data.get("title")
    description = data.get("description")
    rating = data.get("rating")

    new_review = Review(
        product_id=product_id,
        user_id=user_id,
        title=title,
        description=description,
        rating=rating,
    )

    try:
        db.session.add(new_review)
        db.session.commit()
        return jsonify({"message": "Review added successfully"}), 201
    except:
        return jsonify({"message": "Review could not be added"}), 200


""" 
Inventory to be used only by admin
"""


@app.route("/add_inventory", methods=["POST"])
def add_inventory():
    data = request.json
    address = data.get("address")
    provider_name = data.get("provider_name")
    inventory_name = data.get("inventory_name")

    new_inventory = Inventory(
        address=address, provider_name=provider_name, inventory_name=inventory_name
    )
    db.session.add(new_inventory)
    db.session.commit()
    return jsonify({"message": "Inventory added successfully"}), 201


@app.route("/update_inventory/<int:inventory_id>", methods=["PUT"])
def update_inventory(inventory_id):
    inventory = Inventory.query.get(inventory_id)
    data = request.json
    address = data.get("address")
    provider_name = data.get("provider_name")
    inventory_name = data.get("inventory_name")

    if address:
        inventory.address = address
    if provider_name:
        inventory.provider_name = provider_name
    if inventory_name:
        inventory.inventory_name = inventory_name

    db.session.commit()
    return jsonify({"message": "Inventory updated successfully"}), 200


@app.route("/get_inventory/<int:inventory_id>", methods=["GET"])
def get_inventory(inventory_id):
    inventory = Inventory.query.get(inventory_id)
    inventory_data = {
        "id": inventory.id,
        "address": inventory.address,
        "provider_name": inventory.provider_name,
        "inventory_name": inventory.inventory_name,
    }
    return jsonify(inventory_data)


@app.route("/delete_inventory/<int:inventory_id>", methods=["DELETE"])
def delete_inventory(inventory_id):
    inventory = Inventory.query.get(inventory_id)
    db.session.delete(inventory)
    db.session.commit()
    return jsonify({"message": "Inventory deleted successfully"}), 200
