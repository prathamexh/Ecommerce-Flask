
from models import db

def add_product(new_product):
    db.session.add(new_product)
    db.session.commit()