import pytest
from flask import json
from ..app import app


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        with app.app_context():
            # if you have any database setup code, you can add it here
            pass
        yield client
        # if you have any database teardown code, you can add it here


def test_get_user(client):
    response = client.get("/user/1")
    assert response.status_code == 200
    assert json.loads(response.data)["user_data"]["user_id"] == 1


def test_get_user_not_found(client):
    response = client.get("/user/99999")
    assert response.status_code == 404


def test_signup(client):
    user_data = {
        "fname": "Test",
        "lname": "User",
        "email": "testuser@example.com",
        "password": "password",
        "role": "user",
        "address": {
            "address_1": "123 Test St",
            "city": "Test City",
            "postal_code": "12345",
            "country": "Test Country",
        },
        "payment_details": {
            "provider": "Test Provider",
            "credentials": "Test Credentials",
        },
    }
    response = client.post(
        "/signup", data=json.dumps(user_data), content_type="application/json"
    )
    assert response.status_code == 201
    assert json.loads(response.data)["message"] == "User created successfully"


def test_signup_existing_email(client):
    user_data = {
        "fname": "Test",
        "lname": "User",
        "email": "existinguser@example.com",
        "password": "password",
        "role": "user",
        "address": {
            "address_1": "123 Test St",
            "city": "Test City",
            "postal_code": "12345",
            "country": "Test Country",
        },
        "payment_details": {
            "provider": "Test Provider",
            "credentials": "Test Credentials",
        },
    }
    response = client.post(
        "/signup", data=json.dumps(user_data), content_type="application/json"
    )
    assert response.status_code == 400
    assert (
        json.loads(response.data)["message"]
        == "Email already exists. Please use a different email."
    )


def test_login(client):
    user_credentials = {"email": "testuser@example.com", "password": "password"}
    response = client.post(
        "/login", data=json.dumps(user_credentials), content_type="application/json"
    )
    assert response.status_code == 200
    assert json.loads(response.data)["user"]["email"] == "testuser@example.com"


def test_login_invalid_credentials(client):
    user_credentials = {"email": "testuser@example.com", "password": "wrongpassword"}
    response = client.post(
        "/login", data=json.dumps(user_credentials), content_type="application/json"
    )
    assert response.status_code == 401
    assert json.loads(response.data)["message"] == "Invalid email or password"
