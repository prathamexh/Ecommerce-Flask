from flask import Flask, request, jsonify
from models import db, User, Role, Address, Payment_details
import json
import urls as url
import service as service
from flask_cors import CORS
import requests

app = Flask(__name__)


@app.route("/user/<id>", methods=["GET"])
def getUsers(id):
    user = User.query.filter_by(id=id).first()
    if not user:
        return jsonify({"message": "user not found"}), 404
    address = Address.query.filter_by(id=id).first()
    payment_details = Payment_details.query.filter_by(user_id=id).first()
    user_data = {
        "user_id": user.id,
        "fname": user.fname,
        "lname": user.lname,
        "email": user.email,
        "role": user.role_id,  # Return role name instead of role_id
        "ph_number": user.ph_number,
        "address": {
            "address_1": address.address_1,
            "city": address.city,
            "postal_code": address.postal_code,
            "country": address.country,
        },
        "payment_details": {
            "provider": payment_details.provider,
            "credentials": payment_details.credentials,
        },
    }
    return jsonify({"user_data": user_data}), 200


@app.route("/signup", methods=["POST"])
def signup():
    data = request.get_json()
    if (
        "fname" in data
        and "lname" in data
        and "email" in data
        and "password" in data
        and "role" in data
        and "address" in data
        and "payment_details" in data
    ):
        fname = data["fname"]
        lname = data["lname"]
        email = data["email"]
        password = data["password"]
        roley = data["role"]
        address_data = data["address"]
        payment_details_data = data["payment_details"]
        ph_number = data.get("ph_number", None)

        # Check if the email is already registered
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            return (
                jsonify(
                    {"message": "Email already exists. Please use a different email."}
                ),
                400,
            )

        # role = Role.query.filter_by(role=roley).first()
        if roley == "admin":
            role_id = 0
        else:
            role_id = 1
        # Create a new user
        new_user = User(
            fname=fname,
            lname=lname,
            email=email,
            password=password,
            role_id=role_id,
            ph_number=ph_number,
        )

        service.add_user(new_user=new_user)
        new_user = User.query.filter_by(email=email).first()
        add_addresss(
            new_user.id,
            address_data.get("address_1"),
            address_data.get("address_2"),
            address_data.get("city"),
            address_data.get("postal_code"),
            address_data.get("country"),
        )
        add_payment_details(
            new_user.id,
            payment_details_data.get("provider"),
            payment_details_data.get("credentials"),
        )

        return jsonify({"message": "User created successfully"}), 201
    else:
        return jsonify({"message": "hello?"}), 400


def add_balance(user_id):
    response = requests.post(
        url.payment_service_url + "/create_user/", json={"user_id": user_id}
    )


def add_addresss(user_id, address_1, address_2, city, postal_code, country):
    address = Address(
        id=user_id,
        address_1=address_1,
        address_2=address_2,
        city=city,
        postal_code=postal_code,
        country=country,
    )
    # service.add_address(address=address)
    db.session.add(address)
    db.session.commit()
    return jsonify({"message": "Address added successfully"}), 201


def add_payment_details(user_id, provider, credentials):
    payment_details = Payment_details(
        id=user_id, user_id=user_id, provider=provider, credentials=credentials
    )
    service.add_payment(payment_details=payment_details)


@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    if "email" in data and "password" in data:
        email = data["email"]
        password = data["password"]
        user = User.query.filter_by(email=email).first()
        address = Address.query.filter_by(id=user.id).first()
        payment_details = Payment_details.query.filter_by(user_id=user.id).first()

        if user and user.password == password and user.role_id == 1:
            # Return user data including address and payment details if login is successful
            user_data = {
                "user_id": user.id,
                "fname": user.fname,
                "lname": user.lname,
                "email": user.email,
                "role": user.role_id,  # Return role name instead of role_id
                "ph_number": user.ph_number,
                "address": {
                    "address_1": address.address_1,
                    "city": address.city,
                    "postal_code": address.postal_code,
                    "country": address.country,
                },
                "payment_details": {
                    "provider": payment_details.provider,
                    "credentials": payment_details.credentials,
                },
            }
            return jsonify({"user": user_data}), 200
        else:
            return jsonify({"message": "Invalid email or password"}), 401
    else:
        return jsonify({"message": "Missing required fields"}), 400


@app.route("/login/admin", methods=["PUT"])
def admin_login():
    data = request.get_json()
    if "email" in data and "password" in data:
        email = data["email"]
        password = data["password"]
        user = User.query.filter_by(email=email).first()
        address = Address.query.filter_by(id=user.id).first()
        payment_details = Payment_details.query.filter_by(user_id=user.id).first()

        if user and user.password == password and user.role_id == 0:
            # Return user data including address and payment details if login is successful
            user_data = {
                "user_id": user.id,
                "fname": user.fname,
                "lname": user.lname,
                "email": user.email,
                "role": user.role_id,  # Return role name instead of role_id
                "ph_number": user.ph_number,
            }
            return jsonify({"user": user.id}), 200
        else:
            return jsonify({"message": "Invalid email or password"}), 401
    else:
        return jsonify({"message": "Missing required fields"}), 400


@app.route("/signup/admin", methods=["POST"])
def signup_admin():
    data = request.get_json()
    if (
        "fname" in data
        and "lname" in data
        and "email" in data
        and "password" in data
        and "role" in data
    ):
        fname = data["fname"]
        lname = data["lname"]
        email = data["email"]
        password = data["password"]
        roley = data["role"]
        ph_number = data.get("ph_number", None)

        # Check if the email is already registered
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            return (
                jsonify(
                    {"message": "Email already exists. Please use a different email."}
                ),
                400,
            )

        # role = Role.query.filter_by(role=roley).first()
        if roley == "admin":
            role_id = 0
        else:
            role_id = 1
        # Create a new user
        new_user = User(
            fname=fname,
            lname=lname,
            email=email,
            password=password,
            role_id=role_id,
            ph_number=ph_number,
        )

        service.add_user(new_user=new_user)
        new_user = User.query.filter_by(email=email).first()
        return jsonify({"message": "User created successfully"}), 201
    else:
        return jsonify({"message": "error creating a user"}), 400


@app.route("/user/profile/<int:user_id>", methods=["PUT"])
def edit_profile(user_id):
    data = request.get_json()
    user = User.query.filter_by(id=user_id).first()

    if not user:
        return jsonify({"message": "User not found"}), 404

    if "fname" in data:
        user.fname = data["fname"]
    if "lname" in data:
        user.lname = data["lname"]
    if "email" in data:
        user.email = data["email"]
    if "ph_number" in data:
        user.ph_number = data["ph_number"]

    db.session.commit()

    return jsonify({"message": "Profile updated successfully"}), 200


@app.route("/user/address/<int:user_id>", methods=["POST"])
def add_address(user_id):
    data = request.get_json()
    if (
        "address_1" in data
        and "city" in data
        and "postal_code" in data
        and "country" in data
    ):
        address_1 = data["address_1"]
        address_2 = data.get("address_2", None)
        city = data["city"]
        postal_code = data["postal_code"]
        country = data["country"]

        new_address = Address(
            id=user_id,
            address_1=address_1,
            address_2=address_2,
            city=city,
            postal_code=postal_code,
            country=country,
        )

        service.add_address(address=new_address)

        return jsonify({"message": "Address added successfully"}), 201
    else:
        return jsonify({"message": "Missing required fields"}), 400


@app.route("/user/address/<int:user_id>", methods=["PUT"])
def edit_address(user_id):
    address = Address.query.get(user_id)
    if not address:
        return jsonify({"message": "Address not found"}), 404

    data = request.get_json()
    if "address_1" in data:
        address.address_1 = data["address_1"]
    if "address_2" in data:
        address.address_2 = data["address_2"]
    if "city" in data:
        address.city = data["city"]
    if "postal_code" in data:
        address.postal_code = data["postal_code"]
    if "country" in data:
        address.country = data["country"]

    db.session.commit()

    return jsonify({"message": "Address updated successfully"}), 200


@app.route("/addrole", methods=["POST"])
def add_role():
    data = request.get_json()
    role = Role(role=data["role"])
    db.session.add(role)
    db.session.commit()
    return jsonify({"message": "Role added successfully"})


