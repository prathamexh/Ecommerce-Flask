from models import db


def add_user(new_user):
    db.session.add(new_user)
    db.session.commit()
    pass


def add_address(address):
    db.session.add(address)
    db.session.commit()
    pass


def add_payment(payment_details):
    db.session.add(payment_details)
    db.session.commit()
    pass
