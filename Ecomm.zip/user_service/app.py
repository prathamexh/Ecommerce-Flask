from flask import Flask, jsonify
from models import db
from controller import app
from flask_cors import CORS
from flask_swagger import swagger
from flask_swagger_ui import get_swaggerui_blueprint
import json
CORS(app)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///user.db"
# swagger = swagger(app)
db.init_app(app)

# Create the database tables
with app.app_context():
    db.create_all()

# Swagger documentation route
@app.route('/swagger')
def get_swagger():
    swag = swagger(app)
    swag['info']['version'] = "1.0"
    swag['info']['title'] = "My API"
    return jsonify(swag)

# Swagger UI route
SWAGGER_URL = '/swagger-ui'
API_URL = '/swagger'
swaggerui_blueprint = get_swaggerui_blueprint(
    SWAGGER_URL,
    API_URL,
    config={
        'app_name': "My API"
    }
)
app.register_blueprint(swaggerui_blueprint, url_prefix=SWAGGER_URL)
if __name__ == "__main__":
    app.run(debug=True)
