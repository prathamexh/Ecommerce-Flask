import pytest
from flask import Flask
from models import Role, db
from controller import app
from flask_cors import CORS
import json

CORS(app)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///user1.db"
db.init_app(app)

# Create the database tables
with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=True)

# db = SQLAlchemy() should be placed correctly with the db initialization in models.py


# Pytest fixture for creating a test client
@pytest.fixture
def client():
    app.config["TESTING"] = True
    app.config["SQLALCHEMY_DATABASE_URI"] = (
        "sqlite:///test_user.db"  # Use a separate database for testing
    )

    with app.test_client() as client:
        with app.app_context():
            # Setup the test database
            db.create_all()

            # If you have any additional setup code, add it here
            roles = ["Admin", "admin", "customer"]
            for role_name in roles:
                role = Role(role=role_name)
                db.session.add(role)
            db.session.commit()
            pass
        yield client

        # Teardown the test database
        # with app.app_context():
        #     db.drop_all()


def test_signup(client):
    user_data = {
        "fname": "Test",
        "lname": "User",
        "email": "testuser@example.com",
        "password": "password",
        "role": "customer",
        "address": {
            "address_1": "123 Test St",
            "address_2": "123 Test St",
            "city": "Test City",
            "postal_code": 12345,
            "country": "Test Country",
        },
        "payment_details": {
            "provider": "Test Provider",
            "credentials": "Test Credentials",
        },
    }
    response = client.post(
        "/signup", data=json.dumps(user_data), content_type="application/json"
    )
    assert response.status_code == 201
    assert json.loads(response.data)["message"] == "User created successfully"


def test_get_user(client):
    response = client.get("/user/1")
    assert response.status_code == 200
    assert json.loads(response.data)["user_data"]["user_id"] == 1


def test_get_user_not_found(client):
    response = client.get("/user/99999")
    assert response.status_code == 404


def test_signup_existing_email(client):
    user_data = {
        "fname": "Test",
        "lname": "User",
        "email": "testuser@example.com",
        "password": "password",
        "role": "customer",
        "address": {
            "address_1": "123 Test St",
            "city": "Test City",
            "postal_code": 12345,
            "country": "Test Country",
        },
        "payment_details": {
            "provider": "Test Provider",
            "credentials": "Test Credentials",
        },
    }
    response = client.post(
        "/signup", data=json.dumps(user_data), content_type="application/json"
    )
    assert response.status_code == 400


def test_login(client):
    user_credentials = {"email": "testuser@example.com", "password": "password"}
    response = client.post(
        "/login", data=json.dumps(user_credentials), content_type="application/json"
    )
    assert response.status_code == 200


def test_login_invalid_credentials(client):
    user_credentials = {"email": "testuser@example.com", "password": "wrongpassword"}
    response = client.post(
        "/login", data=json.dumps(user_credentials), content_type="application/json"
    )
    assert response.status_code == 401
